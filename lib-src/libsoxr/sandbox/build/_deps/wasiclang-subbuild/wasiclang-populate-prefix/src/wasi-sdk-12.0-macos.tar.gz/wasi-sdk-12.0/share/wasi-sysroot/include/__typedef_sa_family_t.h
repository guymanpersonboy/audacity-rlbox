#ifndef __wasilibc___typedef_sa_family_t_h
#define __wasilibc___typedef_sa_family_t_h

typedef unsigned short sa_family_t;

#endif

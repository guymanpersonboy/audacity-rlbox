#ifndef __wasilibc___typedef_off_t_h
#define __wasilibc___typedef_off_t_h

/* Define these as 64-bit signed integers to support files larger than 2 GiB. */
typedef long long off_t;

#endif
